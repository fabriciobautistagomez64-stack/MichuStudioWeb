'use strict';
const crypto = require('crypto');
const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
let key = '';
for (let i = 0; i < 32; i++) key += alphabet[crypto.randomInt(0, alphabet.length)];
process.stdout.write(key + '\n');
